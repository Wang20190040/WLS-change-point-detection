#' @title Data generation function.
#'
#' @param n sample size
#' @param model range from 1 to 6, specifying the model
#' @param xmodel 1, 2 or 3 specifying the data generation process for covariate x
#' @param noise 1, 2 or 3 specifying the data generation process for noise term
#'
#'
#' @return data x, y
#' @export
#'
#' @examples nfmodel(2000, 1, 1, 1); plot(x, y)
nfmodel <- function(n, model, xmodel, noise){
  theta <- 0.5
  if(model <= 4){
    dim <- 1
  }else if(model == 5){
    dim <- 3
  }else{
    dim <- 6
  }
  switch(xmodel,{
      x <<- matrix(runif(n*dim, -1, 1), n, dim)
    },{
      x <<- matrix(rbeta(n*dim, 1, 2)*2 -1, n, dim)
    },
    {
      x <<- matrix(rbeta(n*dim, 2, 1)*2 -1, n, dim)
    })

  switch(noise,{
    epsilon <- rnorm(n, 0, 1)
  },{
    epsilon <- (rchisq(n, 3)-3)/sqrt(6)
  },{
    epsilon <- rt(n,5)/sqrt(5/3)
  })
  if(dim == 1){
    switch(model,{
      Delta <- sqrt(15*4/2)
      y <<- c(x[1:(n*theta)]^2*Delta,
              ifelse(Delta*x[(n*theta+1):n]>0,
                     Delta -Delta*(x[(n*theta+1):n]-1)^2, Delta*x[(n*theta+1):n]^2)) + epsilon
    },{
      Delta <- (1+sqrt(-1+4))/2
      y <<- c(abs(x[1:(n*theta)])-Delta, Delta-abs(x[(n*theta+1):n])) + epsilon
    },{
      Delta <- sqrt(-4+sqrt(16+18*4))/sqrt(6)
      y <<- (x + rep(c(-1, 0, 1, 0)*Delta,
                     c(0.25*n, 0.25*n, 0.25*n, 0.25*n)))^2 + epsilon
    },{
      Delta <- sqrt(4/2)
      y <<- Delta*sin(pi*x + rep(c(0, 1, 0, 1)*pi/2,
                                 c(0.25*n, 0.25*n, 0.25*n, 0.25*n))) + epsilon
    })
  }else{
    switch(model - 4,{
      y <<- 2*c(cos(pi/2*rowSums(x)[1:(n/4)]), sin(pi/2*rowSums(x)[(n/4+1):(3*n/4)]),
                    cos(pi/2*rowSums(x)[(n/4*3+1):n])) + epsilon
    },{
      y <<- 2*c(cos(pi/2*rowSums(x[,1:2])[1:(n/4)]), sin(pi/2*rowSums(x[,3:4])[(n/4+1):(3*n/4)]),
                    cos(pi/2*rowSums(x[,5:6])[(n/4*3+1):n])) + epsilon
    })
  }
}
