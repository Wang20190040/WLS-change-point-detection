#' @title A cross-validation-based procedure for multiple change-point detection in regression curves.
#'
#' @param y univariate response variable
#' @param x covariate matrix n times p, where n is sample size and p is the dimension
#' @param lx covraite matrix at the grid points with dimension m times p
#' @param K_max maximum change-point number
#' @param Lh a vector with components specifying where the univariate bandwith to be chosen
#' @param Delta minimum change-point number between consecutive estimated change points; note that
#' (K_max+1)*Delta must be smaller the sample size n/2
#'
#' @return A list with two components: h is the selected bandwith; k is the estimated change-point number
#' @export
#'
#' @examples nfmodel(2000, 1, 1, 1); lx <- matrix(x[sample(1:2000, 100),]); Lh <- seq(30, 230, 20)/2000;
#' fcv(y, x, lx, 5, Lh, 100)
fcv <- function(y, x, lx, K_max, Lh, Delta){
  n <- length(y)
  if(is.null(Delta)){
    Delta <- min(floor(n/(K_max+1)), floor(0.05*n))
  }
  if((K_max+1)*Delta >= n/2){
    stop("The product of the maximum change-point number and the minimum distantance must be smaller than the sample size n!")
  }

  n <- dim(x)[1]; m <- dim(x)[2]
  x1 <- x[seq(1, n, 2),]; x2 <- x[seq(2, n, 2),]
  y1 <- y[seq(1, n, 2)]; y2 <- y[seq(2, n, 2)]
  if(m == 1){
    x1 <- matrix(x1); x2 <- matrix(x2)
  }
  A <- matrix(0, length(Lh), K_max);
  for(l in 1:length(Lh)){
    h <- Lh[l]
    cp1 <- fwcp(y1, x1, lx, h, K_max, Delta)$Cpt
    cp2 <- fwcp(y2, x2, lx, h, K_max, Delta)$Cpt
    for(k in 1:K_max){
      A[l,k] <- cost(y, x, lx, sort(cp1[[k]]), sort(cp2[[k]]), h)
    }
  }

  rst <- which(A <= min(A)+1e-8, arr.ind = T)
  list(h = Lh[rst[1]], k = rst[2])
}
