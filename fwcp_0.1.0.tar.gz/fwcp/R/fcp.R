#' @title A penalized procedure for multiple change-point detection in regression curves.
#'
#' @param y univariate response variable
#' @param x covariate matrix n times p, where n is sample size and p is the dimension
#' @param lx covraite matrix at the grid points with dimension m times p
#' @param K_max maximum change-point number
#' @param h the univariate bandwith
#' @param Delta minimum change-point number between consecutive estimated change points, note that
#' K_max*Delta must be smaller the sample size n
#' @param op logical variable, if FALSE the penalty term will be used to select the change-point number;
#' if TRUE then the penalty term will not be used and all change points with change-point number ranging
#' from 1 to K_max will be listed
#' @param penalty used only when op is TRUE with default value exp(3)*(n^p*(log(n))^4)^(1/(p+4))
#'
#' @return a list containing the estimated change-points and corresponding loss function (if op is FALSE)
#' @export
#'
#' @examples nfmodel(2000, 1, 1, 1); lx <- matrix(x[sample(1:2000, 100),]); fcp(y, x, lx, 5, 0.1, 100, TRUE, 10)
fcp <- function(y, x, lx, K_max, h, Delta = NULL, op = TRUE, penalty = NULL){
  n <- dim(x)[1]; p <- dim(x)[2]
  if(is.null(Delta)){
    Delta <- min(floor(n/(K_max+1)), floor(0.05*n))
  }
  if((K_max+1)*Delta >= n){
    stop("The product of the maximum change-point number and the minimum distantance must be smaller than the sample size n!")
  }

  rst <- fwcp(y, x, lx, h, K_max, Delta)
  if(op){
    if(is.null(penalty)){
      penalty <- exp(3)*(n^p*(log(n))^4)^(1/(p+4))
    }
    tp <- which.min((rst$Loss) + 0:K_max * penalty)-1
    rst$Cpt[[tp]]
  }else{
    rst$Cpt
  }

}
