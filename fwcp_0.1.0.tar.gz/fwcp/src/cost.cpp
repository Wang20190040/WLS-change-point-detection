#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double cost(NumericVector y, NumericMatrix x, NumericMatrix lx, NumericVector cp_1, NumericVector cp_2, double h) {
  int n = y.size();
  int m = lx.nrow();
  int d = x.ncol();
  int n_h = n/2;
  double t, cs, pi =3.1415926;
  int K = cp_1.size();
  int lcp, rcp;
  NumericMatrix w1(m, n_h), w2(m, n_h);
  NumericMatrix cw1(m, n_h), cw2(m, n_h);
  NumericVector tcp(K+2);
  for(int i=0; i<m; i++){
    for(int j=0; j<n_h; j++){
      t = 1;
      for(int k=0; k<d; k++){
        t *= exp(-pow((x[2*j]-lx[i])/h, 2.0)/2.0/h)/h/pow(2*pi,0.5);
      }
      w1(i,j) = t>0.00000001?t:0.00000001;
      t = 1;
      for(int k=0; k<d; k++){
        t *= exp(-pow((x[2*j+1]-lx[i])/h, 2.0)/2.0/h)/h/pow(2*pi,0.5);
      }
      w2(i,j) = t>0.00000001?t:0.00000001;;
      if(j<1){
        cw1(i,j) = w1(i,j);
        cw2(i,j) = w2(i,j);
      }else{
        cw1(i,j) = cw1(i,j-1)+w1(i,j);
        cw2(i,j) = cw2(i,j-1)+w2(i,j);
      }
    }
  }
  for(int i=0; i<m; i++){
    if(cw1(i,n_h-1)>0){
      for(int j=0; j<n_h; j++){
        w1(i,j) /= pow(cw1(i,n_h-1),2.0);
        cw1(i,j) /= pow(cw1(i,n_h-1),2.0);
      }
    }
    if(cw2(i,n_h-1)>0){
      for(int j=0; j<n_h; j++){
        w2(i,j) /= pow(cw2(i,n_h-1),2.0);
        cw2(i,j) /= pow(cw2(i,n_h-1),2.0);
      }
    }
  }
  cs = 0;
  for(int l=0; l<2; l++){
    if(l<1){
      tcp[0]=0;
      tcp[K+1]=n_h;
      for(int k=1; k<(K+1); k++){
        tcp[k] = cp_2[k-1];
      }
      for(int j=0; j<m; j++){
        for(int k=0; k<(K+1); k++){
          t = 0;
          lcp = tcp[k];
          rcp = tcp[k+1];
          for(int i=lcp; i<rcp; i++){
            t += y[2*i+1]*w2(j,i);
          }
          if(lcp >0){
            t /= (cw2(j,rcp-1)-cw2(j,lcp-1));
          }else{
            t /= cw2(j,rcp-1);
          }
          for(int i=lcp; i<rcp; i++){
            cs += w1(j,i)*pow(y[2*i]-t,2.0);
          }
        }
      }
    }else{
      tcp[0]=0;
      tcp[K+1]=n_h;
      for(int k=1; k<(K+1); k++){
        tcp[k] = cp_1[k-1];
      }
      for(int j=0; j<m; j++){
        for(int k=0; k<(K+1); k++){
          t = 0;
          lcp = tcp[k];
          rcp = tcp[k+1];
          for(int i=lcp; i<rcp; i++){
            t += y[2*i]*w1(j,i);
          }
          if(lcp >0){
            t /= (cw1(j,rcp-1)-cw1(j,lcp-1));
          }else{
            t /= cw1(j,rcp-1);
          }
          for(int i=lcp; i<rcp; i++){
            cs += w2(j,i)*pow(y[2*i+1]-t,2.0)*pow(n,2.0)/m;
          }
        }
      }
    }
  }
  return cs;
}


/*** R
*/
