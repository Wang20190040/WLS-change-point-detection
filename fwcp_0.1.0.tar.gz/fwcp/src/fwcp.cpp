#include <Rcpp.h>
#include <vector>
using namespace Rcpp;

// [[Rcpp::export]]
List fwcp(NumericVector y, NumericMatrix x, NumericMatrix lx, double h, int KM, int Delta) {
  int n = y.size();
  int m = lx.nrow();
  int d = x.ncol();
  List cpte(KM);
  NumericMatrix w(m, n);
  NumericMatrix cw(m, n);
  NumericMatrix D(KM+1, n+1);
  NumericMatrix I(KM, n+1);
  NumericVector tm(m), tn(m);
  std::vector<double> t1, ts, c1,c2,c3,s1,s2,tp1,tp2,tp3,nts,ts1,ts2,v, loss;
  double t=0, tp, delta, cn, a, b, s, ss1, ss2, pi =3.1415926;
  int size, MP;
  for(int i=0; i<m; i++){
    for(int j=0; j<n; j++){
      t = 1;
      for(int k=0; k<d; k++){
        t *= exp(-pow((x(j,k)-lx(i,k))/h, 2.0)/2.0)/h/pow(2*pi,0.5);
      }
      w(i,j) = t>0.00000001?t:0.00000001;
      if(j<1){
        cw(i,j) = w(i,j);
      }else{
        cw(i,j) = cw(i,j-1)+w(i,j);
      }
    }
  }
  for(int i=0; i<m; i++){
    if(cw(i,n-1)>0){
      for(int j=0; j<n; j++){
        w(i,j) /= pow(cw(i,n-1),2.0);
        cw(i,j) /= pow(cw(i,n-1),2.0);
      }
    }
  }

  for(int k=0; k<=(KM-1); ++k){
    for(int i=0; i<=((k+2)*Delta-1); ++i){
      I(k, i) = (k+1)*Delta;
    }
  }
  for(int k=0; k<=(m-1); ++k){
    tm[k] = y[0];
  }
  D(0,0) = 0;
  for(int i=1; i<=(n-1); ++i){
    t = 0;
    for(int j=0; j<=(m-1); ++j){
      if(cw(j,i)>0){
        t += pow(y[i]-tm[j], 2.0)*cw(j,i-1)*w(j,i)/cw(j,i);
        tm[j] = (tm[j]*cw(j,i-1)+w(j,i)*y[i])/cw(j,i);
      }else{
        tm[j] = 0;
      }
    }
    D(0,i) = D(0,i-1) + t;
  }
  if(KM>1){
    for(int K =1; K<=KM; ++K){
      t = 0;
      for(int k=0; k<=K; k++){
        for(int i=0; i<=(m-1); ++i){
          tm[i] = y[k*Delta];
        }
        if(k>1){
          for(int i=(Delta*k)+1; i<(k+1)*Delta; i++){
            for(int j=0; j<=(m-1); ++j){
              if(cw(j,i)>cw(j,k*Delta-1)+0.00000001){
                t += pow(y[i]-tm[j], 2.0)*(cw(j,i-1)-cw(j,k*Delta-1))*w(j,i)/(cw(j,i)-cw(j,k*Delta-1));
                tm[j] = (tm[j]*(cw(j,i-1)-cw(j,k*Delta-1))+w(j,i)*y[i])/(cw(j,i)-cw(j,k*Delta-1));
              }else{
                tm[j] = 0;
              }
            }
          }
        }else{
          for(int i=1; i<(k+1)*Delta; i++){
            for(int j=0; j<m; ++j){
              if(cw(j,i)>0.00000001){
                t += pow(y[i]-tm[j], 2.0)*cw(j,i-1)*w(j,i)/cw(j,i);
                tm[j] = (tm[j]*cw(j,i-1)+w(j,i)*y[i])/cw(j,i);
              }else{
                tm[j] = 0;
              }
            }
          }
        }
      }
      D(K, (K+1)*Delta-1) = t;
    }}
  for(int K=0; K<=(KM-1); ++K){
    t=0;
    ts.clear();
    c1.clear();
    c2.clear();
    c3.clear();
    ts.push_back((K+1)*Delta);
    for(int j=0; j<=(m-1); ++j){
      s = 0;
      for(int i=((K+1)*Delta); i<=((K+2)*Delta-1); i++){
        s += w(j,i);
      }
      c1.push_back(s);
      s = 0;
      for(int i=((K+1)*Delta); i<=((K+2)*Delta-1); i++){
        s += -2*w(j,i)*y[i];
      }
      c2.push_back(s);
      for(int i=((K+1)*Delta); i<=((K+2)*Delta-1); i++){
        t += w(j,i)*pow(y[i],2.0);
      }
      delta = D(K,(K+2)*Delta-1) - D(K,(K+1)*Delta-1) - t + pow(c2[j],2.0)/4.0/c1[j];
      if(delta >0){
        s1.push_back(-c2[j]/2/c1[j]-sqrt(delta/c1[j]));
        s2.push_back(-c2[j]/2/c1[j]+sqrt(delta/c1[j]));
      }else{
        s1.push_back(INT_MIN);
        s2.push_back(INT_MAX);
      }
    }
    c3.push_back(t+D(K,(K+1)*Delta-1));
    for(int l=((K+2)*Delta-1); l<=(n-2); ++l){
      size = static_cast<int>(ts.size());
      tp1.clear();
      tp2.clear();
      tp3.clear();
      ts1.clear();
      ts2.clear();
      nts.clear();
      if(1){
        for(int j=0; j<size; ++j){
          tp = c3[j] - D(K,l);
          delta = 0;
          for(int i=0; i<=(m-1); ++i){
            delta += pow(c2[j*m+i],2)/4.0/c1[j*m+i];
          }
          delta += -tp;
          if(delta > 0){
            cn = 0;
            for(int i=0; i<=(m-1); ++i){
              a = -c2[j*m+i]/2/c1[j*m+i]-sqrt(delta/c1[j*m+i]);
              b = -c2[j*m+i]/2/c1[j*m+i]+sqrt(delta/c1[j*m+i]);
              tm[i] = a>=s1[j*m+i]?a:s1[j*m+i];
              tn[i] = b<=s2[j*m+i]?b:s2[j*m+i];
              if(tn[i]<tm[i]){
                cn += 1;
              }
            }
            if(cn<1){
              nts.push_back(ts[j]);
              for(int i=0; i<=(m-1); ++i){
                tp1.push_back(c1[j*m+i]);
                tp2.push_back(c2[j*m+i]);
                ts1.push_back(tm[i]);
                ts2.push_back(tn[i]);
              }
              tp3.push_back(c3[j]);
            }
          }
        }
        c1=tp1;
        c2=tp2;
        c3=tp3;
        s1=ts1;
        s2=ts2;
        ts=nts;
      }
      // 加入新的变点及其对应的区间
      size = static_cast<int>(ts.size());
      ts.push_back(l-Delta+2);

      for(int j=0; j<=(m-1); ++j){
        ss1 = 0;
        for(int i=(l-Delta+2); i<=(l+1); i++){
          ss1 += w(j,i);
        }
        ss2 = 0;
        for(int i=(l-Delta+2); i<=(l+1); i++){
          ss2 += -2*w(j,i)*y[i];
        }
        for(int i=(l-Delta+2); i<=(l+1); i++){
          t += w(j,i)*pow(y[i],2.0);
        }
        delta = D(K,l+1) - D(K,l+2-Delta) - t + pow(ss2,2.0)/4.0/ss1;
        if(delta >0){
          s1.push_back(-ss2/2.0/ss1-sqrt(delta/ss1));
          s2.push_back(-ss2/2.0/ss1+sqrt(delta/ss1));
        }else{
          s1.push_back(INT_MIN);
          s2.push_back(INT_MAX);
        }
      }

      // 更新系数

      t=0;
      for(int i=0; i<=(m-1); ++i){
        t += w(i,l+1)*pow(y[l+1],2);
      }
      for(int j=0; j<size; ++j){
        for(int i=0; i<=(m-1); ++i){
          c1[j*m+i] += w(i,l+1);
          c2[j*m+i] += -w(i,l+1)*y[l+1]*2;
        }
        c3[j] += t;
      }

      // 加入新的变点对应的系数

      t=0;
      for(int i=0; i<=(m-1); ++i){
        for(int ii=l-Delta+2; ii<=l+1; ii++){
          t += w(i,ii)*pow(y[ii],2);
        }
      }

      for(int i=0; i<=(m-1); ++i){
        s = 0;
        for(int ii=l-Delta+2; ii<=l+1; ii++){
          s += w(i,ii);
        }
        c1.push_back(s);
        s = 0;
        for(int ii=l-Delta+2; ii<=l+1; ii++){
          s += -2*w(i,ii)*y[ii];
        }
        c2.push_back(s);
      }
      c3.push_back(t+D(K,l-Delta+1));
      v.clear();
      ts1.clear();
      size = static_cast<int>(ts.size());

      // 寻找最小值和对应的变点位置

      for(int j=0; j<size; ++j){
        t=0;
        for(int i=0; i<=(m-1); ++i){
          t += pow(c2[j*m+i],2)/4/c1[j*m+i];
        }
        v.push_back(c3[j]-t);
      }
      MP = min_element(v.begin(), v.end()) - v.begin();
      D(K+1,l+1) = v[MP];
      I(K,l+1) = ts[MP];
    }
  }
  for(int k=0; k<KM; ++k){
    v.clear();
    v.push_back(I(k,n-1));
    if(k>0){
      for(int j=0; j<k; j++){
        v.push_back(I(k-j-1,v[j]-1));
      }
    }
    cpte[k]=v;
  }

  for(int k=0; k<=KM; ++k){
    loss.push_back(D(k, n-1)*pow(n,2.0)/m);
  }

  return(List::create(Named("Cpt")=cpte,
                      Named("Loss")=loss));
}

/*** R
*/
